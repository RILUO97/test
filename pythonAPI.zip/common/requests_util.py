import json

import requests


class RequestUtil:
    session = requests.session()

    def send_request(self, method, url, data, **kwargs):
        method = str(method).lower()
        rep = None
        if method == 'get':
            rep = RequestUtil.session.request(method, url=url, params=data, **kwargs, verify=False)
        else:
            data = json.dumps(data)
            rep = RequestUtil.session.request(method, url=url, data=data, **kwargs, verify=False)
        return rep.text
