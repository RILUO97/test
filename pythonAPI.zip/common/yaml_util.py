import os

import yaml
import time

current_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
current_timestamp = int(time.mktime(time.strptime(current_time, '%Y-%m-%d %H:%M:%S')))
print(current_timestamp)


class YamlUtil:
    def time_time(self):
        current_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        current_timestamp = int(time.mktime(time.strptime(current_time, '%Y-%m-%d %H:%M:%S')))
        return current_timestamp

    # 读取extract.yaml文件
    def read_extract_yaml(self, key):
        with open(os.getcwd() + "/extract.yml", mode='r', encoding='utf-8') as f:
            # f 是文件流  加载方式是Fulloader
            value = yaml.load(stream=f, Loader=yaml.FullLoader)
            return value[key]

    # 写入extract.yaml文件
    def write_extract_yaml(self, data):
        with open(os.getcwd() + "/extract.yml", mode='a', encoding='utf-8') as f:
            yaml.dump(data=data, stream=f, allow_unicode=True)

    # 清除yam文件内容
    def clear_extract_yaml(self):
        with open(os.getcwd() + "/extract.yml", mode='w', encoding='utf-8') as f:
            f.truncate()

    # 读取测试用例yml文件
    def read_testcase_yaml(self, yaml_name):
        with open(os.getcwd() + "/testcases/" + yaml_name, mode='r', encoding='utf-8') as f:
            # f 是文件流  加载方式是Fulloader
            value = yaml.load(stream=f, Loader=yaml.FullLoader)
            return value
