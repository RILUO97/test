import os

import pytest

if __name__ == '__main__':
    pytest.main()
    # 生成allure测试报告
    # os.system("allure generate ./temp -o ./reports --clean")
