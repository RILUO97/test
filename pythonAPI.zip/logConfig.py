import logging, os, time


class loggingComdat():
    def __init__(self):  # 类的初始化方法，调用类时执行
        # 日志格式            时间         日志级别             日志信息
        simple_formatter = '%(asctime)s-%(levelname)s-msg:%(message)s'
        normal_formatter = '%(asctime)s %(levelname)s %(filename)s->%(lineno)s msg:%(message)s'

        self.logger = logging.getLogger('自动化测试')  # 初始化日志对象
        self.logger.setLevel('INFO')  # 设定日志的信息级别
        self.logger.handlers.clear() # 清空打印
        # 设定控制台输出日志信息
        console_log = logging.StreamHandler()  # 初始化控制台信息
        console_log.setLevel('INFO')  # 设置控制台日志的级别

        simple_formatter = logging.Formatter(simple_formatter)  # 初始化日志格式
        console_log.setFormatter(simple_formatter)  # 设定日志格式
        self.logger.addHandler(console_log)  # 将控制台作为日志输出通道

        # 设定日志输出到日志文件
        # 设计日志文件的名字
        now = time.strftime('%Y-%m-%d', time.localtime())
        file_name = 'runtime.log'  # 日志文件名
        logPath = r'D:\pythonAPI\testcases'  # 日志文件保存的路径
        log_file_name = os.path.join(logPath, file_name)  # 将日志文件名和路径拼接
        self.file_log = logging.FileHandler(log_file_name, encoding='utf-8')  # 初始化日志文件
        self.file_log.setLevel('DEBUG')  # 设置文件中打印的日志级别
        normal_formatter = logging.Formatter(normal_formatter)  # 初始化日志格式
        self.file_log.setFormatter(normal_formatter)  # 将日志格式应用到日志文件中
        self.logger.addHandler(self.file_log)  # 将日志文件作为日志输出通道

    def get_logger(self):
        return self.logger

    def close_log(self):
        self.logger.removeHandler(self.file_log)  # 移除日志输出
        self.file_log.close()


do_logger = loggingComdat().get_logger()

if __name__ == '__main__':
    do_logger.error('这是一个错误')
    do_logger.info('这是一个正确的信息')
