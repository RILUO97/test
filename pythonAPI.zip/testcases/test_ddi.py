import json
import time

import pytest
import yaml
import time

from common.requests_util import RequestUtil
from common.yaml_util import YamlUtil
from testcases.md5 import api_md5

timestamp = int(time.time())


class Test_ddi:

    @pytest.mark.parametrize('caseinfo', YamlUtil().read_testcase_yaml('test_ddi.yml'))
    def test_list(self, caseinfo):
        print(caseinfo['name'])
        method = caseinfo['request']['method']
        url = caseinfo['request']['url']
        data = {
            "api_id": 1,
            "timestamp": timestamp,
            "sign": api_md5().md5custom('getTiBuckets'),
            "action": "getTiBuckets",
        }
        result = RequestUtil().send_request(method, url, data)
        result = json.loads(result)
        print(result)

    @pytest.mark.parametrize('caseinfo', YamlUtil().read_testcase_yaml('test_ddi.yml'))
    def test_data(self, caseinfo):
        print(caseinfo['name'])
        method = caseinfo['request']['method']
        url = caseinfo['request']['url']
        data = {
            "api_id": 1,
            "timestamp": timestamp,
            "sign": api_md5().md5custom('setTiData'),
            "action": "setTiData",
            "bucket_id": 2,
            "datas": ["192.168.3.134"]
        }
        result = RequestUtil().send_request(method, url, data)
        result = json.loads(result)
        print(result)

    # def test_mac(self):
    #     url = 'http://192.168.3.144:9000/v2/ipam/mac/black/'
    #     method = 'post'
    #     data = {
    #         "X-App-Code": 1,
    #         "X-App-Sign": api_md5().md5custom(''),
    #         "X-App-Timestamp": timestamp,
    #         "Content-Type": "application/json",
    #         "mac": "F8:94:C2:4B:6B:53"
    #     }
    #     result = RequestUtil().send_request(method, url, data)
    #     # result = json.loads(result)
    #     print(result)


if __name__ == '__main__':
    pytest.mark()
