import pytest


class TestApi:
    # @pytest.mark.parametrize('args',['百里','星曜','一人'])
    # def test_api1(self,args):
    #     print("args")
    @pytest.mark.parametrize('name,age', [["baili",13],['xingyao',23]])
    def test_api2(self,name,age):
        print(name,age)
if __name__ == '__main__':
    pytest.main(['-vs','a_test_api.py'])