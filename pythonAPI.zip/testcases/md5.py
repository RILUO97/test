import hashlib
import time


class api_md5:

    def sha256(self):
        api_id = '1'
        api_key = '8b5b8c779cb72054a7f04057549d7a64'
        timestamp = str(int(round(time.time())))
        s = api_key + api_id + timestamp
        # s = s.encode('utf-8')
        hash_object = hashlib.sha256()
        hash_object.update(s.encode(encoding='utf-8'))
        hash_value = hash_object.hexdigest()
        return hash_value

    def md5(self, api_id, api_key, action):
        timestamp = str(int(round(time.time())))
        s = api_id + api_key + action + timestamp
        h = hashlib.md5()
        h.update(s.encode(encoding='utf-8'))
        return h.hexdigest()

    def md5custom(self, action):
        api_id = '1'
        api_key = '11f47eb68be4eab94b5895ae5496e051'
        timestamp = str(int(round(time.time())))
        s = api_id + api_key + action + timestamp
        h = hashlib.md5()
        h.update(s.encode(encoding='utf-8'))
        return h.hexdigest()
