import pytest
from logConfig import loggingComdat
from common.yaml_util import YamlUtil


@pytest.fixture(scope="function")
def conn_database():
    print("连接数据库")
    yield
    print("关闭数据库")


@pytest.fixture(scope="session", autouse=True)
def clear_yaml():
    YamlUtil().clear_extract_yaml()


@pytest.fixture(scope="function")
def logger():
    logger = loggingComdat().get_logger()
    yield logger
    loggingComdat().close_log()
