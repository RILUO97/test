import json
import pytest
from common.requests_util import RequestUtil
from common.yaml_util import YamlUtil
import time
from testcases.md5 import api_md5

timestamp = int(time.time())


class Test_rump:
    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_data(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getSitesCount'),
                "action": 'getSitesCount'
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            print(result)
            logger.info(result)
            logger.info('这是一条网站数据接口')
        except Exception as e:
            logger.error('网站数据接口错误信息{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_log(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getSite'),
                "action": 'getSite',
                "id": '1'
            }
            result = RequestUtil().send_request(method, url, data)
            logger.info(result)
            logger.info('这是一条weblog接口')
        except Exception as e:
            logger.error('weblog接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_list(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getSite'),
                "action": 'getSites',
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条网站列表接口')
        except Exception as e:
            logger.error('网站列表接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_onLine(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('onLine'),
                "action": 'onLine',
                "ids": [4]
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条web上线接口')
        except Exception as e:
            logger.error("web上线接口错误信息:{}".format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_offLine(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('offLine'),
                "action": 'offLine',
                "ids": [4]
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条web下线接口')
        except Exception as e:
            logger.error('web下线接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_getBeianDefNames(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getBeianDefNames'),
                "action": 'getBeianDefNames',
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条获取备案接口')
        except Exception as e:
            logger.error('获取备案接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_getBeianTemplate(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getBeianTemplate'),
                "action": 'getBeianTemplate',
                "id": 3
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条获取备案模板接口')
        except Exception as e:
            logger.error('获取备案模板接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_web_addBeian(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('addBeian'),
                "action": "addBeian",
                "username": "myadm",
                "id": 3,
                "data": [
                    [
                        {
                            "id": "TextField-name",
                            "label": "网站/信息系统名称",
                            "value": "教务系统"
                        },
                        {
                            "id": "DDSelectField-wkt4mt",
                            "label": "网站分类",
                            "value": "临时分类"
                        },
                        {
                            "id": "TextField-domain",
                            "label": "域名",
                            "value": "jw.sec.wst.com"
                        },
                        {
                            "id": "TextField-ip",
                            "label": "IP 信息",
                            "value": "42.51.51.51"
                        },
                        {
                            "id": "NumberField-port",
                            "label": "开放端口",
                            "value": 80
                        },
                        {
                            "id": "TextField-8cm33b",
                            "label": "所属部门/院系",
                            "value": "网络中心"
                        },
                        {
                            "id": "TextField-nb44zh",
                            "label": "网站用途",
                            "value": "教学办公"
                        },
                        {
                            "id": "DDDropDownField-5ia7ga",
                            "label": "操作系统",
                            "value": "Centos 7.8"
                        },
                        {
                            "id": "DDDropDownField-0m3zrk",
                            "label": "数据库",
                            "value": "MySQL"
                        },
                        {
                            "id": "DDSelectField-n0wj3t",
                            "label": "服务对象",
                            "value": "内网"
                        },
                        {
                            "id": "TextField-kxt8n5",
                            "label": "存放地点",
                            "value": "数据中心"
                        },
                        {
                            "id": "TextField-wjmv8h",
                            "label": "开发单位",
                            "value": "XXX 科技"
                        },
                        {
                            "id": "TextField-ljtasi",
                            "label": "运维服务提供方",
                            "value": "XXX 科技"
                        },
                        {
                            "id": "TextField-k8b3qv",
                            "label": "部门负责人姓名",
                            "value": "张三"
                        },
                        {
                            "id": "TextField-17o2d9",
                            "label": "部门负责人工号",
                            "value": "111111"
                        },
                        {
                            "id": "TextField-kzxhwd",
                            "label": "部门负责人电话",
                            "value": "222222"
                        },
                        {
                            "id": "TextField-cx4off",
                            "label": "部门负责人手机",
                            "value": "333333"
                        },
                        {
                            "id": "TextField-yta684",
                            "label": "部门负责人邮箱",
                            "value": "support@xxxxxx.cn"
                        },
                        {
                            "id": "TextField-gwqsl5",
                            "label": "网站管理员姓名",
                            "value": "李四"
                        },
                        {
                            "id": "TextField-15fn7t",
                            "label": "网站管理员工号",
                            "value": "444444"
                        },
                        {
                            "id": "TextField-w385jg",
                            "label": "网站管理员电话",
                            "value": "555555"
                        },
                        {
                            "id": "TextField-hl0qya",
                            "label": "网站管理员手机",
                            "value": "666666"
                        },
                        {
                            "id": "TextField-9bsq5c",
                            "label": "网站管理员邮箱",
                            "value": "support@xxxxxx.cn"
                        },
                        {
                            "id": "DDSelectField-19zw2v",
                            "label": "等级保护测评定级",
                            "value": "二级"
                        },
                        {
                            "id": "TextField-f25r8t",
                            "label": "ICP 备案信息",
                            "value": "豫 ICP 备 xxxxxx"
                        },
                        {
                            "id": "DDSelectField-sja9lb",
                            "label": "证明材料",
                            "value": "否"
                        }
                    ]
                ]
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条add接口')
        except Exception as e:
            logger.error('add备案接口错误信息:{}'.format(e))

    @pytest.mark.parametrize('case_info', YamlUtil().read_testcase_yaml('test_rump.yml'))
    def test_getBeianTasks(self, case_info, logger):
        try:
            print(case_info['name'])
            method = case_info['request']['method']
            url = case_info['request']['url']
            data = {
                "api_id": 1,
                "timestamp": timestamp,
                "sign": api_md5().md5custom('getBeianTasks'),
                "action": "getBeianTasks",
                "id": 3,
                "username": "myadm"
            }
            result = RequestUtil().send_request(method, url, data)
            result = json.loads(result)
            # print(result)
            logger.info(result)
            logger.info('这是一条备案Tasks接口')
        except Exception as e:
            logger.error('备案Tasks接口错误信息:{}'.format(e))


if __name__ == '__main__':
    pytest.main()
