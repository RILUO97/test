import json
import re

import pytest
import requests
from common.yaml_util import YamlUtil
from common.requests_util import RequestUtil


class TestSendrequest:
    # session = requests.session()
    # csrf_tokne = ''
    # @pytest.mark.smoke
    @pytest.mark.parametrize('caseinfo', YamlUtil().read_testcase_yaml('get_token.yml'))
    def test_phone(self, caseinfo):
        # 发送get请求
        print(caseinfo['name'])
        print(caseinfo['validate'])
        method = caseinfo['request']['method']
        url = caseinfo['request']['url']
        data = caseinfo['request']['data']
        # header= caseinfo['request']['headers']
        result = RequestUtil().send_request(method, url, data)
        # result = TestSendrequest.session.request(method,url=url,data=date,headers=header)
        result = json.loads(result)
        print(result)
        # if 'resultcode' in result:
        #     YamlUtil().write_extract_yaml({'resultcode':rep.json()['resultcode']})
        if 'reason' in result:
            YamlUtil().write_extract_yaml({'reason': result['reason']})
        else:
            assert result['error_code'] == 200101
            # assert result['City'] in result

        # else:
        #     assert result['resultcode'] !=20
        #     print('错误')
    # 需要请求投的接口和需要token的接口测试
    # @pytest.mark.smoke
    # def test_start(self):
    #     url = 'http://47.107.116.139/phpwind/'
    #     rep = TestSendrequest.session.request('get',url=url)
    #     result = rep.status_code
    #     YamlUtil().write_extract_yaml({'csrf_token': re.search('name="csrf_token" value="(.*?)"',rep.text)[1]})
    #     # assert result == 200
    #
    #     # 正则表达式提取token
    #     # TestSendrequest.csrf_tokne = re.search('name="csrf_token" value="(.*?)"',rep.text)[1]
    # #请求需要带请求头
    # @pytest.mark.smoke
    # def test_login(self):
    #     csrf_token = YamlUtil().read_extract_yaml('csrf_token')
    #     url = 'http://47.107.116.139/phpwind/index.php?m=u&c=login&a=dorun'
    #     data = {
    #         "username":'msxy',
    #         "password":'msxy',
    #         "csrf_token": csrf_token,
    #         "backurl":'http://47.107.116.139/phpwind',
    #         "invite":""
    #     }
    #     headers= {
    #         "Accept":"application/json,test/javascript,/; q=0.01",
    #         "X-Requested-with":"XMLHttpRequest"
    #     }
    #     rep = TestSendrequest.session.request('post',url=url,data=data,headers=headers)
    #     print(rep.json())


if __name__ == '__main__':
    pytest.main()
