import dns.resolver
import time
import random

# 定义测试的域名
domain_list = ['test.com', 'test.com', 'test.com', 'test.com']

# 定义测试次数
test_times = 10


# 进行DNS查询
def dns_query(server, domain):
    resolver = dns.resolver.Resolver(configure=False)
    resolver.nameservers = [server]
    response_time = 0
    try:
        # 获取开始时间
        start_time = time.time()
        # 进行DNS查询
        answer = resolver.query(domain)
        # 获取结束时间
        end_time = time.time()
        # 计算响应时间
        response_time = round((end_time - start_time) * 1000, 2)
    except Exception as e:
        print(e)
    return response_time


# 进行压测
if __name__ == '__main__':
    # 输入DNS服务器地址
    server = input('请输入DNS服务器地址：')

    total_time = 0
    for i in range(test_times):
        domain = random.choice(domain_list)
        response_time = dns_query(server, domain)
        total_time += response_time
        print(f'{domain}: 响应时间 {response_time}ms')
    avg_time = round(total_time / test_times, 2)
    print(f'平均响应时间：{avg_time}ms')
